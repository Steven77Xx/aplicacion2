package xyz.devleen.primer;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private EditText editTextElectores;
    private TextView textViewResultado;

    private int votosCandidato1;
    private int votosCandidato2;
    private int votosCandidato3;

    private int electoresRestantes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextElectores = findViewById(R.id.editTextElectores);
        textViewResultado = findViewById(R.id.textViewResultado);
    }

    public void iniciarElecciones(View view) {
        votosCandidato1 = 0;
        votosCandidato2 = 0;
        votosCandidato3 = 0;

        int numElectores = Integer.parseInt(editTextElectores.getText().toString());
        electoresRestantes = numElectores;

        ingresarEdades(numElectores);
    }

    public void iniciarIngresoEdades(View view) {
        int numElectores = Integer.parseInt(editTextElectores.getText().toString());
        ingresarEdades(numElectores);
    }

    private void ingresarEdades(int numElectores) {
        electoresRestantes = numElectores;
        solicitarEdad();
    }

    private void solicitarEdad() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edad del Elector");
        builder.setMessage("Ingrese la edad del elector:");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Aceptar", (dialog, which) -> {
            int edad = Integer.parseInt(input.getText().toString());

            if (edad < 18) {
                mostrarMensaje("El elector es menor de edad y no puede votar.");
            } else {
                electoresRestantes--;
                solicitarVoto();
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void solicitarVoto() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Voto del Elector");
        builder.setMessage("Ingrese el voto del elector (1, 2 o 3):");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Aceptar", (dialog, which) -> {
            int voto = Integer.parseInt(input.getText().toString());
            switch (voto) {
                case 1:
                    votosCandidato1++;
                    break;
                case 2:
                    votosCandidato2++;
                    break;
                case 3:
                    votosCandidato3++;
                    break;
                default:
                    mostrarMensaje("Voto inválido. Por favor elija 1, 2 o 3.");
                    break;
            }

            if (electoresRestantes > 0) {
                solicitarEdad();
            } else {
                mostrarResultado();
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void mostrarMensaje(String mensaje) {
        textViewResultado.setText(mensaje);
    }

    private void mostrarResultado() {
        int candidatoGanador = determinarGanador();
        String mensajeResultado = "El Candidato #" + candidatoGanador + " ganó con " + obtenerVotos(candidatoGanador) + " votos.";
        textViewResultado.setText(mensajeResultado);
    }

    private int determinarGanador() {
        int maxVotos = Math.max(votosCandidato1, Math.max(votosCandidato2, votosCandidato3));
        if (maxVotos == votosCandidato1) {
            return 1;
        } else if (maxVotos == votosCandidato2) {
            return 2;
        } else {
            return 3;
        }
    }

    private int obtenerVotos(int candidato) {
        switch (candidato) {
            case 1:
                return votosCandidato1;
            case 2:
                return votosCandidato2;
            case 3:
                return votosCandidato3;
            default:
                return 0;
        }
    }
}

